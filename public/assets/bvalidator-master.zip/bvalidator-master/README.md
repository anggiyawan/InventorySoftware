# bValidator

bValidator is a form validation jQuery plug-in.

See documentation and examples [here](http://bmauser.github.io/bvalidator).
